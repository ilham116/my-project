<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Podarki_Box by ENGE</title>
	<meta name="description" content="Podarki_Box - сделайте каждый праздник незабываемым"/>
	<meta name="keyword" content="подарки,подарки на каждый праздник,подарки Box"/>
	<link rel="stylesheet" type="text/css" href="css/style_contacts.css">
</head>
<body>
	<header>
		<?php require "blocks/header.php" ?>
	</header>
  <section class="contacts_banner">
    <div class="text_cont">
	  Телефон:+79370000004<br><br>
	  Почта:Podarki_box@gmail.com<br><br>
	  График работы:<br> ПН-ПТ 8:00-18:00<br> СБ-ВС выходной
    </div>
	<footer>
		<div class="container">
	<div class="footer_container">
		<div class="info_dostavka">
			<a href="Information_dost.php" class="info_exp">Информация о доставке</a>
		</div>
				<div>
				<h4>©𝟚𝟘𝟚𝟘 ℙ𝕠𝕕𝕒𝕣𝕜𝕚_𝔹𝕠𝕩 𝕓𝕪 𝔼ℕ𝔾𝔼 </h4>
					</div>

	<div class="info_soglashenie">
		<a href="Pol_sogl.php" class="info_sogl">Условия соглашения</a>
	</div>
	</div>
	</div>
	</footer>
</body>
</html>
