<?php

setcookie('user', $user['name'], time() - 3600, "/");

header('Location:/Podarki_box_by_ENGE.php');
