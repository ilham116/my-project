<div class="container">
<div class="footer_container">
  <div class="info_dostavka">
    <a href="Information_dost.php" class="info_exp">Информация о доставке</a>
  </div>
      <div>
      <h4>©𝟚𝟘𝟚𝟘 ℙ𝕠𝕕𝕒𝕣𝕜𝕚_𝔹𝕠𝕩 𝕓𝕪 𝔼ℕ𝔾𝔼 </h4>
        </div>

<div class="info_soglashenie">
  <a href="Pol_sogl.php" class="info_sogl">Условия соглашения</a>
</div>
</div>
</div>
