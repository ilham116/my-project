<div class="container">
  <nav>
  <ul>
    <li><a href="Podarki_box_by_ENGE.php  "> Главная </a></li>
    <li><a href="Podarki_Box.php"> Подарки Box </a></li>
    <li><a href=""> Отзывы </a></li>
    <li><a href="Contacts.php"> Контакты </a></li>
  </ul>
    </nav>
  <div class="Logo" >
  <img src="img/Logo.png" alt="Podarki_Box">
  </div>
      <div class="korzina_button">
        <a href="" class="korz_but"><span class="link">В корзину</span></a>
      </div>
  <div class="vxod_button">
    <a href="Vxod_button_box.php" class="vxod_but"><span class="link-content">Войти</span></a>
  </div>

  </div>
